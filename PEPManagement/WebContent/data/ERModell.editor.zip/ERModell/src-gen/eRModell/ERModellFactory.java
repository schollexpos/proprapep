/**
 */
package eRModell;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see eRModell.ERModellPackage
 * @generated
 */
public interface ERModellFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ERModellFactory eINSTANCE = eRModell.impl.ERModellFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>ER Modell</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>ER Modell</em>'.
	 * @generated
	 */
	ERModell createERModell();

	/**
	 * Returns a new object of class '<em>Entitaetstyp</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Entitaetstyp</em>'.
	 * @generated
	 */
	Entitaetstyp createEntitaetstyp();

	/**
	 * Returns a new object of class '<em>Beziehungstyp</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Beziehungstyp</em>'.
	 * @generated
	 */
	Beziehungstyp createBeziehungstyp();

	/**
	 * Returns a new object of class '<em>Attribut</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Attribut</em>'.
	 * @generated
	 */
	Attribut createAttribut();

	/**
	 * Returns a new object of class '<em>Rolle</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Rolle</em>'.
	 * @generated
	 */
	Rolle createRolle();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ERModellPackage getERModellPackage();

} //ERModellFactory
