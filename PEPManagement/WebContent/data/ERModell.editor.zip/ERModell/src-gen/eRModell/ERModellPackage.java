/**
 */
package eRModell;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see eRModell.ERModellFactory
 * @model kind="package"
 * @generated
 */
public interface ERModellPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "eRModell";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/eRModell";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "eRModell";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ERModellPackage eINSTANCE = eRModell.impl.ERModellPackageImpl.init();

	/**
	 * The meta object id for the '{@link eRModell.impl.ERModellImpl <em>ER Modell</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see eRModell.impl.ERModellImpl
	 * @see eRModell.impl.ERModellPackageImpl#getERModell()
	 * @generated
	 */
	int ER_MODELL = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ER_MODELL__NAME = 0;

	/**
	 * The number of structural features of the '<em>ER Modell</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ER_MODELL_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>ER Modell</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ER_MODELL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link eRModell.impl.EntitaetstypImpl <em>Entitaetstyp</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see eRModell.impl.EntitaetstypImpl
	 * @see eRModell.impl.ERModellPackageImpl#getEntitaetstyp()
	 * @generated
	 */
	int ENTITAETSTYP = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITAETSTYP__NAME = 0;

	/**
	 * The feature id for the '<em><b>PSchl�ssel</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITAETSTYP__PSCHL�SSEL = 1;

	/**
	 * The number of structural features of the '<em>Entitaetstyp</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITAETSTYP_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Entitaetstyp</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITAETSTYP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link eRModell.impl.BeziehungstypImpl <em>Beziehungstyp</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see eRModell.impl.BeziehungstypImpl
	 * @see eRModell.impl.ERModellPackageImpl#getBeziehungstyp()
	 * @generated
	 */
	int BEZIEHUNGSTYP = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BEZIEHUNGSTYP__NAME = 0;

	/**
	 * The number of structural features of the '<em>Beziehungstyp</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BEZIEHUNGSTYP_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Beziehungstyp</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BEZIEHUNGSTYP_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link eRModell.impl.AttributImpl <em>Attribut</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see eRModell.impl.AttributImpl
	 * @see eRModell.impl.ERModellPackageImpl#getAttribut()
	 * @generated
	 */
	int ATTRIBUT = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUT__NAME = 0;

	/**
	 * The feature id for the '<em><b>Datentyp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUT__DATENTYP = 1;

	/**
	 * The number of structural features of the '<em>Attribut</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Attribut</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link eRModell.impl.RolleImpl <em>Rolle</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see eRModell.impl.RolleImpl
	 * @see eRModell.impl.ERModellPackageImpl#getRolle()
	 * @generated
	 */
	int ROLLE = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLLE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Kardinalit�t</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLLE__KARDINALIT�T = 1;

	/**
	 * The number of structural features of the '<em>Rolle</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLLE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Rolle</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROLLE_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link eRModell.ERModell <em>ER Modell</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>ER Modell</em>'.
	 * @see eRModell.ERModell
	 * @generated
	 */
	EClass getERModell();

	/**
	 * Returns the meta object for the attribute '{@link eRModell.ERModell#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see eRModell.ERModell#getName()
	 * @see #getERModell()
	 * @generated
	 */
	EAttribute getERModell_Name();

	/**
	 * Returns the meta object for class '{@link eRModell.Entitaetstyp <em>Entitaetstyp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Entitaetstyp</em>'.
	 * @see eRModell.Entitaetstyp
	 * @generated
	 */
	EClass getEntitaetstyp();

	/**
	 * Returns the meta object for the attribute '{@link eRModell.Entitaetstyp#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see eRModell.Entitaetstyp#getName()
	 * @see #getEntitaetstyp()
	 * @generated
	 */
	EAttribute getEntitaetstyp_Name();

	/**
	 * Returns the meta object for the attribute '{@link eRModell.Entitaetstyp#getPSchl�ssel <em>PSchl�ssel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>PSchl�ssel</em>'.
	 * @see eRModell.Entitaetstyp#getPSchl�ssel()
	 * @see #getEntitaetstyp()
	 * @generated
	 */
	EAttribute getEntitaetstyp_PSchl�ssel();

	/**
	 * Returns the meta object for class '{@link eRModell.Beziehungstyp <em>Beziehungstyp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Beziehungstyp</em>'.
	 * @see eRModell.Beziehungstyp
	 * @generated
	 */
	EClass getBeziehungstyp();

	/**
	 * Returns the meta object for the attribute '{@link eRModell.Beziehungstyp#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see eRModell.Beziehungstyp#getName()
	 * @see #getBeziehungstyp()
	 * @generated
	 */
	EAttribute getBeziehungstyp_Name();

	/**
	 * Returns the meta object for class '{@link eRModell.Attribut <em>Attribut</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attribut</em>'.
	 * @see eRModell.Attribut
	 * @generated
	 */
	EClass getAttribut();

	/**
	 * Returns the meta object for the attribute '{@link eRModell.Attribut#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see eRModell.Attribut#getName()
	 * @see #getAttribut()
	 * @generated
	 */
	EAttribute getAttribut_Name();

	/**
	 * Returns the meta object for the attribute '{@link eRModell.Attribut#getDatentyp <em>Datentyp</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Datentyp</em>'.
	 * @see eRModell.Attribut#getDatentyp()
	 * @see #getAttribut()
	 * @generated
	 */
	EAttribute getAttribut_Datentyp();

	/**
	 * Returns the meta object for class '{@link eRModell.Rolle <em>Rolle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Rolle</em>'.
	 * @see eRModell.Rolle
	 * @generated
	 */
	EClass getRolle();

	/**
	 * Returns the meta object for the attribute '{@link eRModell.Rolle#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see eRModell.Rolle#getName()
	 * @see #getRolle()
	 * @generated
	 */
	EAttribute getRolle_Name();

	/**
	 * Returns the meta object for the attribute '{@link eRModell.Rolle#getKardinalit�t <em>Kardinalit�t</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Kardinalit�t</em>'.
	 * @see eRModell.Rolle#getKardinalit�t()
	 * @see #getRolle()
	 * @generated
	 */
	EAttribute getRolle_Kardinalit�t();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ERModellFactory getERModellFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link eRModell.impl.ERModellImpl <em>ER Modell</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see eRModell.impl.ERModellImpl
		 * @see eRModell.impl.ERModellPackageImpl#getERModell()
		 * @generated
		 */
		EClass ER_MODELL = eINSTANCE.getERModell();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ER_MODELL__NAME = eINSTANCE.getERModell_Name();

		/**
		 * The meta object literal for the '{@link eRModell.impl.EntitaetstypImpl <em>Entitaetstyp</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see eRModell.impl.EntitaetstypImpl
		 * @see eRModell.impl.ERModellPackageImpl#getEntitaetstyp()
		 * @generated
		 */
		EClass ENTITAETSTYP = eINSTANCE.getEntitaetstyp();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITAETSTYP__NAME = eINSTANCE.getEntitaetstyp_Name();

		/**
		 * The meta object literal for the '<em><b>PSchl�ssel</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ENTITAETSTYP__PSCHL�SSEL = eINSTANCE.getEntitaetstyp_PSchl�ssel();

		/**
		 * The meta object literal for the '{@link eRModell.impl.BeziehungstypImpl <em>Beziehungstyp</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see eRModell.impl.BeziehungstypImpl
		 * @see eRModell.impl.ERModellPackageImpl#getBeziehungstyp()
		 * @generated
		 */
		EClass BEZIEHUNGSTYP = eINSTANCE.getBeziehungstyp();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BEZIEHUNGSTYP__NAME = eINSTANCE.getBeziehungstyp_Name();

		/**
		 * The meta object literal for the '{@link eRModell.impl.AttributImpl <em>Attribut</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see eRModell.impl.AttributImpl
		 * @see eRModell.impl.ERModellPackageImpl#getAttribut()
		 * @generated
		 */
		EClass ATTRIBUT = eINSTANCE.getAttribut();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUT__NAME = eINSTANCE.getAttribut_Name();

		/**
		 * The meta object literal for the '<em><b>Datentyp</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUT__DATENTYP = eINSTANCE.getAttribut_Datentyp();

		/**
		 * The meta object literal for the '{@link eRModell.impl.RolleImpl <em>Rolle</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see eRModell.impl.RolleImpl
		 * @see eRModell.impl.ERModellPackageImpl#getRolle()
		 * @generated
		 */
		EClass ROLLE = eINSTANCE.getRolle();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROLLE__NAME = eINSTANCE.getRolle_Name();

		/**
		 * The meta object literal for the '<em><b>Kardinalit�t</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROLLE__KARDINALIT�T = eINSTANCE.getRolle_Kardinalit�t();

	}

} //ERModellPackage
