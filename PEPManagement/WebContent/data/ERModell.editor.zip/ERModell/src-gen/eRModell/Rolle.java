/**
 */
package eRModell;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Rolle</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link eRModell.Rolle#getName <em>Name</em>}</li>
 *   <li>{@link eRModell.Rolle#getKardinalit�t <em>Kardinalit�t</em>}</li>
 * </ul>
 *
 * @see eRModell.ERModellPackage#getRolle()
 * @model
 * @generated
 */
public interface Rolle extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see eRModell.ERModellPackage#getRolle_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link eRModell.Rolle#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Kardinalit�t</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Kardinalit�t</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Kardinalit�t</em>' attribute.
	 * @see #setKardinalit�t(String)
	 * @see eRModell.ERModellPackage#getRolle_Kardinalit�t()
	 * @model
	 * @generated
	 */
	String getKardinalit�t();

	/**
	 * Sets the value of the '{@link eRModell.Rolle#getKardinalit�t <em>Kardinalit�t</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Kardinalit�t</em>' attribute.
	 * @see #getKardinalit�t()
	 * @generated
	 */
	void setKardinalit�t(String value);

} // Rolle
