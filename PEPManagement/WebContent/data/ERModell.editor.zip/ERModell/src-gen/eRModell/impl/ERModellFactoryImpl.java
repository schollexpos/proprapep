/**
 */
package eRModell.impl;

import eRModell.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ERModellFactoryImpl extends EFactoryImpl implements ERModellFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ERModellFactory init() {
		try {
			ERModellFactory theERModellFactory = (ERModellFactory) EPackage.Registry.INSTANCE
					.getEFactory(ERModellPackage.eNS_URI);
			if (theERModellFactory != null) {
				return theERModellFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ERModellFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ERModellFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ERModellPackage.ER_MODELL:
			return createERModell();
		case ERModellPackage.ENTITAETSTYP:
			return createEntitaetstyp();
		case ERModellPackage.BEZIEHUNGSTYP:
			return createBeziehungstyp();
		case ERModellPackage.ATTRIBUT:
			return createAttribut();
		case ERModellPackage.ROLLE:
			return createRolle();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ERModell createERModell() {
		ERModellImpl erModell = new ERModellImpl();
		return erModell;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Entitaetstyp createEntitaetstyp() {
		EntitaetstypImpl entitaetstyp = new EntitaetstypImpl();
		return entitaetstyp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Beziehungstyp createBeziehungstyp() {
		BeziehungstypImpl beziehungstyp = new BeziehungstypImpl();
		return beziehungstyp;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Attribut createAttribut() {
		AttributImpl attribut = new AttributImpl();
		return attribut;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Rolle createRolle() {
		RolleImpl rolle = new RolleImpl();
		return rolle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ERModellPackage getERModellPackage() {
		return (ERModellPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ERModellPackage getPackage() {
		return ERModellPackage.eINSTANCE;
	}

} //ERModellFactoryImpl
